from . import hr_leave_report_balance
from . import hr_leave_report_used
from . import hr_leave_report_employee
from . import hr_leave_report_allocation
from . import hr_leave_report_timeoff
from . import hr_leave_report_inherit
